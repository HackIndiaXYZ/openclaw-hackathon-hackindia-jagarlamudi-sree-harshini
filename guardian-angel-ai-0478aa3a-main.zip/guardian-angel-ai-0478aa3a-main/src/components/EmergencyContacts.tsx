import { motion } from "framer-motion";
import { Users, Phone, Plus } from "lucide-react";

const contacts = [
  { name: "Sarah Doe", relation: "Spouse", phone: "+1-555-0123", avatar: "SD" },
  { name: "Dr. Smith", relation: "Primary Doctor", phone: "+1-555-0456", avatar: "DS" },
  { name: "City Hospital", relation: "Nearby Hospital", phone: "911", avatar: "CH" },
];

const EmergencyContacts = () => {
  return (
    <motion.div
      initial={{ y: 20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ delay: 0.2 }}
      className="rounded-xl bg-gradient-card border border-border p-5 shadow-card"
    >
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-bold text-foreground flex items-center gap-2">
          <Users className="w-5 h-5 text-safe" />
          Emergency Contacts
        </h3>
        <button className="p-2 rounded-lg bg-secondary hover:bg-secondary/80 transition-colors">
          <Plus className="w-4 h-4 text-muted-foreground" />
        </button>
      </div>

      <div className="space-y-3">
        {contacts.map((contact, i) => (
          <motion.div
            key={contact.name}
            initial={{ x: -20, opacity: 0 }}
            animate={{ x: 0, opacity: 1 }}
            transition={{ delay: 0.3 + i * 0.1 }}
            className="flex items-center justify-between bg-secondary/40 rounded-lg p-3"
          >
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 rounded-full bg-gradient-emergency flex items-center justify-center text-sm font-bold text-emergency-foreground">
                {contact.avatar}
              </div>
              <div>
                <p className="text-sm font-semibold text-foreground">{contact.name}</p>
                <p className="text-xs text-muted-foreground">{contact.relation}</p>
              </div>
            </div>
            <a
              href={`tel:${contact.phone}`}
              className="p-2 rounded-lg bg-safe/15 hover:bg-safe/25 transition-colors"
            >
              <Phone className="w-4 h-4 text-safe" />
            </a>
          </motion.div>
        ))}
      </div>
    </motion.div>
  );
};

export default EmergencyContacts;
