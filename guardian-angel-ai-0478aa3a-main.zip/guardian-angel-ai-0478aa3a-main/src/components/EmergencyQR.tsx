import { motion } from "framer-motion";
import { QRCodeSVG } from "qrcode.react";
import { QrCode, Share2 } from "lucide-react";

const EmergencyQR = () => {
  const emergencyData = JSON.stringify({
    name: "John Doe",
    blood: "O+",
    allergies: ["Penicillin", "Peanuts"],
    conditions: ["Asthma"],
    organDonor: true,
    emergency: "+1-555-0123",
  });

  return (
    <motion.div
      initial={{ y: 20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ delay: 0.3 }}
      className="rounded-xl bg-gradient-card border border-border p-5 shadow-card"
    >
      <div className="flex items-center justify-between mb-4">
        <h3 className="text-lg font-bold text-foreground flex items-center gap-2">
          <QrCode className="w-5 h-5 text-info" />
          Emergency QR
        </h3>
        <button className="p-2 rounded-lg bg-secondary hover:bg-secondary/80 transition-colors">
          <Share2 className="w-4 h-4 text-muted-foreground" />
        </button>
      </div>

      <div className="flex flex-col items-center gap-4">
        <div className="bg-foreground p-3 rounded-xl">
          <QRCodeSVG
            value={emergencyData}
            size={160}
            bgColor="hsl(210, 20%, 95%)"
            fgColor="hsl(220, 20%, 7%)"
            level="M"
          />
        </div>
        <p className="text-xs text-muted-foreground text-center max-w-[200px]">
          Scan to view emergency health summary. Works offline.
        </p>
      </div>
    </motion.div>
  );
};

export default EmergencyQR;
