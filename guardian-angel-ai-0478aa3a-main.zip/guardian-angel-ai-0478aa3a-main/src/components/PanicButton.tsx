import { useState, useCallback } from "react";
import { motion, AnimatePresence } from "framer-motion";
import { Phone, X, Shield } from "lucide-react";

const PanicButton = () => {
  const [isActive, setIsActive] = useState(false);
  const [isCancelling, setIsCancelling] = useState(false);
  const [countdown, setCountdown] = useState(3);

  const handleActivate = useCallback(() => {
    setIsActive(true);
    setCountdown(3);

    let count = 3;
    const timer = setInterval(() => {
      count -= 1;
      setCountdown(count);
      if (count <= 0) {
        clearInterval(timer);
        // Trigger emergency actions
        setIsActive(false);
        setIsCancelling(false);
      }
    }, 1000);

    setIsCancelling(true);
    // Store timer for cancellation
    (window as any).__panicTimer = timer;
  }, []);

  const handleCancel = useCallback(() => {
    clearInterval((window as any).__panicTimer);
    setIsActive(false);
    setIsCancelling(false);
    setCountdown(3);
  }, []);

  return (
    <div className="flex flex-col items-center gap-6">
      <AnimatePresence mode="wait">
        {!isActive ? (
          <motion.button
            key="panic"
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.8, opacity: 0 }}
            whileTap={{ scale: 0.95 }}
            onClick={handleActivate}
            className="relative w-44 h-44 rounded-full bg-gradient-emergency shadow-emergency flex items-center justify-center cursor-pointer group"
          >
            {/* Pulse rings */}
            <span className="absolute inset-0 rounded-full animate-pulse-emergency" />
            <span className="absolute inset-[-8px] rounded-full border-2 border-emergency/20 animate-ping-slow" />

            <div className="flex flex-col items-center gap-2 z-10">
              <Phone className="w-10 h-10 text-emergency-foreground" />
              <span className="text-sm font-bold tracking-wider uppercase text-emergency-foreground">
                SOS
              </span>
            </div>
          </motion.button>
        ) : (
          <motion.div
            key="countdown"
            initial={{ scale: 0.8, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            exit={{ scale: 0.8, opacity: 0 }}
            className="relative w-44 h-44 rounded-full border-4 border-emergency bg-card flex items-center justify-center"
          >
            <motion.span
              key={countdown}
              initial={{ scale: 2, opacity: 0 }}
              animate={{ scale: 1, opacity: 1 }}
              className="text-6xl font-black text-emergency"
            >
              {countdown}
            </motion.span>
          </motion.div>
        )}
      </AnimatePresence>

      <AnimatePresence>
        {isCancelling && (
          <motion.button
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            exit={{ y: 20, opacity: 0 }}
            onClick={handleCancel}
            className="flex items-center gap-2 px-6 py-3 rounded-full bg-secondary text-secondary-foreground font-semibold hover:bg-secondary/80 transition-colors"
          >
            <X className="w-4 h-4" />
            Cancel
          </motion.button>
        )}
      </AnimatePresence>

      {!isActive && (
        <div className="flex items-center gap-2 text-muted-foreground text-sm">
          <Shield className="w-4 h-4" />
          <span>Press to activate emergency alert</span>
        </div>
      )}
    </div>
  );
};

export default PanicButton;
