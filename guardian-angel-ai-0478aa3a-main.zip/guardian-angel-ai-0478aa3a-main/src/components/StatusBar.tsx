import { motion } from "framer-motion";
import { Shield, Wifi, MapPin, Battery } from "lucide-react";

const StatusBar = () => {
  return (
    <motion.div
      initial={{ y: -20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      className="flex items-center justify-between px-4 py-3 bg-card/50 border-b border-border backdrop-blur-sm"
    >
      <div className="flex items-center gap-2">
        <div className="w-2 h-2 rounded-full bg-safe animate-pulse" />
        <span className="text-xs font-semibold text-safe">System Active</span>
      </div>

      <div className="flex items-center gap-3">
        <div className="flex items-center gap-1 text-muted-foreground">
          <MapPin className="w-3.5 h-3.5" />
          <span className="text-xs">GPS</span>
        </div>
        <div className="flex items-center gap-1 text-muted-foreground">
          <Wifi className="w-3.5 h-3.5" />
          <span className="text-xs">Online</span>
        </div>
        <div className="flex items-center gap-1 text-muted-foreground">
          <Shield className="w-3.5 h-3.5 text-safe" />
        </div>
      </div>
    </motion.div>
  );
};

export default StatusBar;
