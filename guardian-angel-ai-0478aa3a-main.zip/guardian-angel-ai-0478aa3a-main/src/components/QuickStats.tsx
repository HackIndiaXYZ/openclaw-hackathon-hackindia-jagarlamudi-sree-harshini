import { motion } from "framer-motion";
import { Heart, Thermometer, Wind, Droplets } from "lucide-react";

const stats = [
  { icon: Heart, label: "Heart Rate", value: "72", unit: "bpm", color: "text-emergency" },
  { icon: Thermometer, label: "Temp", value: "98.6", unit: "°F", color: "text-warning" },
  { icon: Wind, label: "SpO2", value: "98", unit: "%", color: "text-info" },
  { icon: Droplets, label: "BP", value: "120/80", unit: "", color: "text-safe" },
];

const QuickStats = () => {
  return (
    <div className="grid grid-cols-4 gap-2">
      {stats.map((stat, i) => (
        <motion.div
          key={stat.label}
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.05 * i }}
          className="bg-gradient-card border border-border rounded-xl p-3 flex flex-col items-center gap-1"
        >
          <stat.icon className={`w-4 h-4 ${stat.color}`} />
          <span className="text-lg font-bold text-foreground">{stat.value}</span>
          <span className="text-[10px] text-muted-foreground">{stat.unit || stat.label}</span>
        </motion.div>
      ))}
    </div>
  );
};

export default QuickStats;
