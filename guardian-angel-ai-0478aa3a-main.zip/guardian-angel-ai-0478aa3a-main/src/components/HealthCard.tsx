import { motion } from "framer-motion";
import { Heart, Droplets, AlertTriangle, Pill, Activity } from "lucide-react";

interface HealthData {
  bloodGroup: string;
  allergies: string[];
  conditions: string[];
  medications: string[];
  organDonor: boolean;
  riskLevel: "low" | "medium" | "high";
}

const defaultData: HealthData = {
  bloodGroup: "O+",
  allergies: ["Penicillin", "Peanuts"],
  conditions: ["Asthma", "Hypertension"],
  medications: ["Albuterol", "Lisinopril"],
  organDonor: true,
  riskLevel: "medium",
};

const riskColors = {
  low: "bg-safe text-safe-foreground",
  medium: "bg-warning text-warning-foreground",
  high: "bg-emergency text-emergency-foreground",
};

const riskLabels = {
  low: "Low Risk",
  medium: "Medium Risk",
  high: "High Risk",
};

const HealthCard = ({ data = defaultData }: { data?: HealthData }) => {
  return (
    <motion.div
      initial={{ y: 20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ delay: 0.1 }}
      className="rounded-xl bg-gradient-card border border-border p-5 shadow-card space-y-4"
    >
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-bold text-foreground flex items-center gap-2">
          <Activity className="w-5 h-5 text-emergency" />
          Health Black Box
        </h3>
        <span className={`text-xs font-bold px-3 py-1 rounded-full ${riskColors[data.riskLevel]}`}>
          {riskLabels[data.riskLevel]}
        </span>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <div className="bg-secondary/50 rounded-lg p-3 flex items-center gap-3">
          <Droplets className="w-5 h-5 text-emergency" />
          <div>
            <p className="text-xs text-muted-foreground">Blood Group</p>
            <p className="text-xl font-bold text-foreground">{data.bloodGroup}</p>
          </div>
        </div>

        <div className="bg-secondary/50 rounded-lg p-3 flex items-center gap-3">
          <Heart className="w-5 h-5 text-emergency" />
          <div>
            <p className="text-xs text-muted-foreground">Organ Donor</p>
            <p className="text-lg font-bold text-foreground">{data.organDonor ? "Yes" : "No"}</p>
          </div>
        </div>
      </div>

      <div className="space-y-2">
        <div className="flex items-start gap-2">
          <AlertTriangle className="w-4 h-4 text-warning mt-0.5 shrink-0" />
          <div>
            <p className="text-xs text-muted-foreground mb-1">Allergies</p>
            <div className="flex flex-wrap gap-1">
              {data.allergies.map((a) => (
                <span key={a} className="text-xs bg-warning/15 text-warning px-2 py-0.5 rounded-full font-medium">
                  {a}
                </span>
              ))}
            </div>
          </div>
        </div>

        <div className="flex items-start gap-2">
          <Pill className="w-4 h-4 text-info mt-0.5 shrink-0" />
          <div>
            <p className="text-xs text-muted-foreground mb-1">Medications</p>
            <div className="flex flex-wrap gap-1">
              {data.medications.map((m) => (
                <span key={m} className="text-xs bg-info/15 text-info px-2 py-0.5 rounded-full font-medium">
                  {m}
                </span>
              ))}
            </div>
          </div>
        </div>
      </div>
    </motion.div>
  );
};

export default HealthCard;
