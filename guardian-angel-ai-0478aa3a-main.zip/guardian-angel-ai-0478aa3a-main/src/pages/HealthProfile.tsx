import { motion } from "framer-motion";
import { ArrowLeft, Save, Activity, Droplets, AlertTriangle, Pill, Heart, FileText } from "lucide-react";
import { useNavigate } from "react-router-dom";
import { useState } from "react";
import StatusBar from "@/components/StatusBar";
import BottomNav from "@/components/BottomNav";

const HealthProfile = () => {
  const navigate = useNavigate();
  const [formData, setFormData] = useState({
    bloodGroup: "O+",
    allergies: "Penicillin, Peanuts",
    conditions: "Asthma, Hypertension",
    medications: "Albuterol, Lisinopril",
    surgeries: "Appendectomy (2019)",
    insurance: "BlueCross #12345",
    organDonor: true,
  });

  const handleChange = (field: string, value: string | boolean) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  return (
    <div className="min-h-screen bg-background pb-24">
      <StatusBar />

      <div className="max-w-lg mx-auto px-4 py-6 space-y-6">
        <motion.div
          initial={{ x: -20, opacity: 0 }}
          animate={{ x: 0, opacity: 1 }}
          className="flex items-center gap-3"
        >
          <button onClick={() => navigate("/")} className="p-2 rounded-lg bg-secondary hover:bg-secondary/80 transition-colors">
            <ArrowLeft className="w-5 h-5 text-foreground" />
          </button>
          <div>
            <h1 className="text-xl font-bold text-foreground flex items-center gap-2">
              <Activity className="w-5 h-5 text-emergency" />
              Health Black Box
            </h1>
            <p className="text-xs text-muted-foreground">Your critical medical data</p>
          </div>
        </motion.div>

        <motion.div
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.1 }}
          className="space-y-4"
        >
          {[
            { icon: Droplets, label: "Blood Group", field: "bloodGroup", color: "text-emergency" },
            { icon: AlertTriangle, label: "Allergies", field: "allergies", color: "text-warning" },
            { icon: Heart, label: "Chronic Conditions", field: "conditions", color: "text-emergency" },
            { icon: Pill, label: "Current Medications", field: "medications", color: "text-info" },
            { icon: FileText, label: "Past Surgeries", field: "surgeries", color: "text-muted-foreground" },
            { icon: FileText, label: "Insurance Details", field: "insurance", color: "text-safe" },
          ].map((item) => (
            <div key={item.field} className="bg-gradient-card border border-border rounded-xl p-4 space-y-2">
              <label className="flex items-center gap-2 text-sm font-semibold text-foreground">
                <item.icon className={`w-4 h-4 ${item.color}`} />
                {item.label}
              </label>
              <input
                type="text"
                value={formData[item.field as keyof typeof formData] as string}
                onChange={(e) => handleChange(item.field, e.target.value)}
                className="w-full bg-secondary/50 border border-border rounded-lg px-3 py-2.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-emergency/30 focus:border-emergency/50 transition-all"
              />
            </div>
          ))}

          <div className="bg-gradient-card border border-border rounded-xl p-4">
            <label className="flex items-center justify-between cursor-pointer">
              <span className="flex items-center gap-2 text-sm font-semibold text-foreground">
                <Heart className="w-4 h-4 text-safe" />
                Organ Donor
              </span>
              <div
                className={`w-12 h-6 rounded-full transition-colors relative ${formData.organDonor ? "bg-safe" : "bg-secondary"}`}
                onClick={() => handleChange("organDonor", !formData.organDonor)}
              >
                <div
                  className={`absolute top-0.5 w-5 h-5 rounded-full bg-foreground transition-transform ${formData.organDonor ? "translate-x-6" : "translate-x-0.5"}`}
                />
              </div>
            </label>
          </div>
        </motion.div>

        <motion.button
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="w-full flex items-center justify-center gap-2 py-3 rounded-xl bg-gradient-emergency text-emergency-foreground font-bold shadow-emergency hover:opacity-90 transition-opacity"
        >
          <Save className="w-5 h-5" />
          Save Health Data
        </motion.button>
      </div>

      <BottomNav />
    </div>
  );
};

export default HealthProfile;
