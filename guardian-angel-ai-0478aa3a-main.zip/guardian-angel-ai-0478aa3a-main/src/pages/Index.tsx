import { motion } from "framer-motion";
import StatusBar from "@/components/StatusBar";
import PanicButton from "@/components/PanicButton";
import HealthCard from "@/components/HealthCard";
import QuickStats from "@/components/QuickStats";
import EmergencyContacts from "@/components/EmergencyContacts";
import EmergencyQR from "@/components/EmergencyQR";
import BottomNav from "@/components/BottomNav";

const Index = () => {
  return (
    <div className="min-h-screen bg-background pb-24">
      <StatusBar />

      <div className="max-w-lg mx-auto px-4 py-6 space-y-6">
        {/* Header */}
        <motion.div
          initial={{ y: -10, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="text-center space-y-1"
        >
          <h1 className="text-2xl font-black tracking-tight">
            <span className="text-gradient-emergency">Safe</span>
            <span className="text-foreground">Pulse</span>
            <span className="text-info">+</span>
          </h1>
          <p className="text-xs text-muted-foreground font-medium tracking-wide uppercase">
            Intelligent Emergency Response
          </p>
        </motion.div>

        {/* Panic Button */}
        <PanicButton />

        {/* Quick Stats */}
        <QuickStats />

        {/* Health Card */}
        <HealthCard />

        {/* Emergency Contacts */}
        <EmergencyContacts />

        {/* QR Code */}
        <EmergencyQR />
      </div>

      <BottomNav />
    </div>
  );
};

export default Index;
