import { motion } from "framer-motion";
import { ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";
import StatusBar from "@/components/StatusBar";
import EmergencyContacts from "@/components/EmergencyContacts";
import BottomNav from "@/components/BottomNav";

const ContactsPage = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-background pb-24">
      <StatusBar />
      <div className="max-w-lg mx-auto px-4 py-6 space-y-6">
        <motion.div initial={{ x: -20, opacity: 0 }} animate={{ x: 0, opacity: 1 }} className="flex items-center gap-3">
          <button onClick={() => navigate("/")} className="p-2 rounded-lg bg-secondary hover:bg-secondary/80 transition-colors">
            <ArrowLeft className="w-5 h-5 text-foreground" />
          </button>
          <h1 className="text-xl font-bold text-foreground">Emergency Contacts</h1>
        </motion.div>
        <EmergencyContacts />
      </div>
      <BottomNav />
    </div>
  );
};

export default ContactsPage;
