import { motion } from "framer-motion";
import { ArrowLeft } from "lucide-react";
import { useNavigate } from "react-router-dom";
import StatusBar from "@/components/StatusBar";
import EmergencyQR from "@/components/EmergencyQR";
import BottomNav from "@/components/BottomNav";

const QRPage = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-background pb-24">
      <StatusBar />
      <div className="max-w-lg mx-auto px-4 py-6 space-y-6">
        <motion.div initial={{ x: -20, opacity: 0 }} animate={{ x: 0, opacity: 1 }} className="flex items-center gap-3">
          <button onClick={() => navigate("/")} className="p-2 rounded-lg bg-secondary hover:bg-secondary/80 transition-colors">
            <ArrowLeft className="w-5 h-5 text-foreground" />
          </button>
          <h1 className="text-xl font-bold text-foreground">Emergency QR Code</h1>
        </motion.div>
        <EmergencyQR />
        <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ delay: 0.2 }} className="bg-gradient-card border border-border rounded-xl p-5 space-y-3">
          <h3 className="text-sm font-bold text-foreground">How it works</h3>
          <ul className="space-y-2 text-xs text-muted-foreground">
            <li>• Anyone can scan your QR to view critical health info</li>
            <li>• Works offline — data is embedded in the code</li>
            <li>• Share via NFC tag on wearable or wallet card</li>
            <li>• Emergency responders get instant access</li>
          </ul>
        </motion.div>
      </div>
      <BottomNav />
    </div>
  );
};

export default QRPage;
