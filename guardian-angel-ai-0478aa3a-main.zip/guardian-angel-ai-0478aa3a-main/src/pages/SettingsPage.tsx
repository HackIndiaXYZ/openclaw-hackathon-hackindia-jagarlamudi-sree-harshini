import { motion } from "framer-motion";
import { ArrowLeft, Bell, Shield, Globe, Smartphone, LogOut } from "lucide-react";
import { useNavigate } from "react-router-dom";
import StatusBar from "@/components/StatusBar";
import BottomNav from "@/components/BottomNav";

const settings = [
  { icon: Bell, label: "Notifications", desc: "Alert preferences" },
  { icon: Shield, label: "Privacy & Security", desc: "Data visibility controls" },
  { icon: Globe, label: "Language", desc: "English" },
  { icon: Smartphone, label: "Wearable Devices", desc: "Connect smartwatch" },
];

const SettingsPage = () => {
  const navigate = useNavigate();

  return (
    <div className="min-h-screen bg-background pb-24">
      <StatusBar />
      <div className="max-w-lg mx-auto px-4 py-6 space-y-6">
        <motion.div initial={{ x: -20, opacity: 0 }} animate={{ x: 0, opacity: 1 }} className="flex items-center gap-3">
          <button onClick={() => navigate("/")} className="p-2 rounded-lg bg-secondary hover:bg-secondary/80 transition-colors">
            <ArrowLeft className="w-5 h-5 text-foreground" />
          </button>
          <h1 className="text-xl font-bold text-foreground">Settings</h1>
        </motion.div>

        <div className="space-y-2">
          {settings.map((item, i) => (
            <motion.button
              key={item.label}
              initial={{ x: -20, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ delay: 0.05 * i }}
              className="w-full flex items-center gap-4 bg-gradient-card border border-border rounded-xl p-4 hover:border-emergency/20 transition-colors text-left"
            >
              <item.icon className="w-5 h-5 text-muted-foreground" />
              <div className="flex-1">
                <p className="text-sm font-semibold text-foreground">{item.label}</p>
                <p className="text-xs text-muted-foreground">{item.desc}</p>
              </div>
            </motion.button>
          ))}
        </div>

        <motion.button
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="w-full flex items-center justify-center gap-2 py-3 rounded-xl border border-emergency/30 text-emergency font-semibold hover:bg-emergency/10 transition-colors"
        >
          <LogOut className="w-4 h-4" />
          Sign Out
        </motion.button>
      </div>
      <BottomNav />
    </div>
  );
};

export default SettingsPage;
